#!/usr/bin/env bash
gcc -w cable.c -o cable
